#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#ifdef _WIN32
    #define LIMPAR_TELA "cls"
#else
    #define LIMPAR_TELA "clear"
#endif

#define NUM_MIN 1
#define NUM_MAX 63
#define MAX_INPUT 100

// Declarações de funções
void limparTela();
void aguardarTecla();
void exibirMenu();
int lerOpcao();
int lerInteiroEntre(int min, int max);
char lerCharSN();
void iniciarJogo(int modo);
void exibirCartao(int cartao);
int calcularNumero(int respostas[]);

int main() {
    int opcao;
    srand((unsigned) time(NULL)); // Inicializa gerador de números aleatórios

    do {
        limparTela();
        exibirMenu();
        opcao = lerOpcao();

        switch (opcao) {
            case 1:
            case 2:
                iniciarJogo(opcao);
                break;
            case 3:
                printf("\nJogo encerrado. Ate breve!\n");
                break;
            default:
                printf("Opcao invalida! Tente novamente.\n");
                aguardarTecla();
        }
    } while (opcao != 3);

    return 0;
}

void exibirMenu() {
    printf("===== JOGO MAGIC6 =====\n");
    printf("1 - Computador adivinha o numero\n");
    printf("2 - Jogador adivinha o numero\n");
    printf("3 - Sair do jogo\n");
    printf("=======================\n");
}

int lerOpcao() {
    printf("Escolha uma opcao: ");
    return lerInteiroEntre(1, 3);
}

int lerInteiroEntre(int min, int max) {
    char entrada[MAX_INPUT];
    int valor;

    while (1) {
        fgets(entrada, sizeof(entrada), stdin);
        if (sscanf(entrada, "%d", &valor) == 1 && valor >= min && valor <= max)
            return valor;
        printf("Entrada invalida. Insira um numero entre %d e %d: ", min, max);
    }
}

char lerCharSN() {
    char entrada[MAX_INPUT], resposta;

    while (1) {
        printf("Deseja jogar novamente? (S/N): ");
        fgets(entrada, sizeof(entrada), stdin);
        if (sscanf(entrada, " %c", &resposta) == 1) {
            resposta = toupper(resposta);
            if (resposta == 'S' || resposta == 'N')
                return resposta;
        }
        printf("Entrada invalida. Digite S para sim ou N para nao.\n");
    }
}

void iniciarJogo(int modo) {
    char jogarNovamente;

    do {
        limparTela();

        if (modo == 1) {
            printf("--- Modo: Computador adivinha ---\n");
            int respostas[6] = {0};

            for (int i = 1; i <= 6; i++) {
                exibirCartao(i);
                printf("O numero esta neste cartao? (1 = Sim, 0 = Na
			o): ");
                respostas[i - 1] = lerInteiroEntre(0, 1);
            }

            int numero = calcularNumero(respostas);
            printf("\nO numero pensado e: ** %d **\n", numero);

        } else {
            printf("--- Modo: Jogador adivinha ---\n");
            int numero = (rand() % NUM_MAX) + NUM_MIN;

            printf("Observe os cartoes:\n");
            for (int i = 1; i <= 6; i++) {
                if (numero & (1 << (i - 1))) {
                    exibirCartao(i);
                }
            }

            printf("Qual e o numero? ");
            int palpite = lerInteiroEntre(NUM_MIN, NUM_MAX);

            if (palpite == numero) {
                printf("Parabens! Voce acertou.\n");
            } else {
                printf("Voce errou! O numero era: %d\n", numero);
            }
        }

        jogarNovamente = lerCharSN();

    } while (jogarNovamente == 'S');
}

void exibirCartao(int cartao) {
    printf("\n[ Cartao %d ]\n", cartao);
    for (int i = NUM_MIN; i <= NUM_MAX; i++) {
        if (i & (1 << (cartao - 1))) {
            printf("%2d ", i);
        }
    }
    printf("\n");
}

int calcularNumero(int respostas[]) {
    int numero = 0;
    for (int i = 0; i < 6; i++) {
        if (respostas[i]) {
            numero += (1 << i);
        }
    }
    return numero;
}

void limparTela() {
    system(LIMPAR_TELA);
}

void aguardarTecla() {
    printf("\nPressione Enter para continuar...");
    while (getchar() != '\n');
}
